using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyStore.Pages.Admin.Products
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
